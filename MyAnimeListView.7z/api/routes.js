'use strict';
module.exports = function (app) {
    let viewCtrl = require('./controllers/ViewController');

    // todoList Routes
    app.route('/view/:id')
        .get(viewCtrl.get);
};